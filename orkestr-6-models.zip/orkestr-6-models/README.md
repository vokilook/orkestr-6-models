# Оркестр — 6 моделей (выбор перед отправкой + история)

Готовый проект для Vercel: выбираете 1 из 6 моделей, каждый запрос уходит с полной перепиской.

## Модели (полные имена)
- `nvidia/nemotron-3.5-lightning:free` — Nemotron 3.5 Lightning
- `cohere/north-mini-code:free` — North Mini Code
- `nvidia/nemotron-3-ultra-550b-a55b:free` — Nemotron 3 Ultra 550B
- `google/gemma-4-31b-it:free` — Gemma 4 31B
- `google/gemma-4-26b-a4b-it:free` — Gemma 4 26B A4B
- `thinkingmachines/inkling-2-small:free` — Inkling 2 Small

## Деплой на Vercel (через браузер, 2 мин)

1. Создайте новый репозиторий на `github.com` → `New repository` → загрузите эту папку `orkestr-6-models` (`Upload files`)
2. На `vercel.com` → `Add New` → `Project` → `Import` ваш репо → `Deploy`
3. `vercel.com` → ваш проект → `Settings` → `Environment Variables` → `Add`:
   - `Key: ORKESTR_OPENROUTER_KEY` | `Value: <ваш ключ OpenRouter>` | `Environments: Production, Preview` | `Save`
4. `Deployments` → `Redeploy` (три точки `⋯` → `Redeploy`)
5. Откройте `https://ваш-проект.vercel.app` — выберите модель в выпадающем списке, пишите задачу. Каждый `Отправить` шлёт `messages: [...вся история, новый user]`.

## Как работает история
Фронтенд хранит `history=[{role:'user'},{role:'assistant'},...]` в памяти вкладки и каждый `POST /api/chat` отправляет все 20 последних сообщений целиком. Сервер прокидывает их в OpenRouter без обрезки.

## Лимиты
Ваш ключ: `1000/день, 20/мин` (проверили через `/api/check`). Inkling часто `403 agentic_harness_only`, Gemma — `429` в пик.

## Локально
```bash
npm i -g vercel
ORKESTR_OPENROUTER_KEY=sk-... vercel dev
```
