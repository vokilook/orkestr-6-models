import { createRequire } from 'module';
const OPENROUTER = 'https://openrouter.ai/api/v1';

const MODELS = {
  "nvidia/nemotron-3.5-lightning:free": "Nemotron 3.5 Lightning (free)",
  "cohere/north-mini-code:free": "North Mini Code (free)",
  "nvidia/nemotron-3-ultra-550b-a55b:free": "Nemotron 3 Ultra (free)",
  "google/gemma-4-31b-it:free": "Gemma 4 31B (free)",
  "google/gemma-4-26b-a4b-it:free": "Gemma 4 26B A4B (free)",
  "thinkingmachines/inkling-2-small:free": "Inkling 2 Small (free)"
};

export default async function handler(req, res) {
  if (req.method === 'GET') {
    return res.status(200).json({ models: Object.entries(MODELS).map(([id,label])=>({id,label})), ok: true });
  }
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  let body='';
  for await (const chunk of req) body+=chunk;
  let payload;
  try { payload=JSON.parse(body); } catch { return res.status(400).json({error:'Invalid JSON'}); }

  const model = payload.model;
  const messages = payload.messages;
  if (!MODELS[model]) return res.status(400).json({error:'Выберите модель из списка 6'});
  if (!Array.isArray(messages) || !messages.length) return res.status(400).json({error:'Нет сообщений'});

  // Ключ только с сервера — как в Оркестре с serverKeys:true
  const key = process.env.ORKESTR_OPENROUTER_KEY || process.env.OPENROUTER_API_KEY;
  if (!key) return res.status(500).json({error:'ORKESTR_OPENROUTER_KEY не задан на Vercel'});

  // Ограничим историю: последние 20 сообщений, 100k символов
  const trimmed = messages.slice(-20).map(m=>({role:m.role, content:String(m.content).slice(0,20000)})).filter(m=>m.role==='user'||m.role==='assistant');

  try {
    const r = await fetch(`${OPENROUTER}/chat/completions`, {
      method:'POST',
      headers:{ 'Authorization':`Bearer ${key}`, 'Content-Type':'application/json', 'HTTP-Referer':'https://orkestr-6-models.vercel.app', 'X-Title':'Orkestr 6 Models' },
      body: JSON.stringify({ model, messages: trimmed, temperature: 0.7, max_tokens: 4096 })
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({error: data.error?.message || `OpenRouter ${r.status}`, details:data});
    const content = data.choices?.[0]?.message?.content || '';
    return res.status(200).json({ ok:true, model, content, usage:data.usage });
  } catch (e) {
    return res.status(500).json({error: String(e.message||e).slice(0,400)});
  }
}
